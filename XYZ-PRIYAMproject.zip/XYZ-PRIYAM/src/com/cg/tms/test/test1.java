package com.cg.tms.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class test1 
{

	@Test
	public void test() {
		

}
	public class TicketTest {
		TicketDAO daoRef1;
	    @Before
		public void before()
		{
			daoRef1=new TicketDAOImpl();
		}
		
		
		@Test
		public void test() {
			
			TicketCategory ticketCategory=new TicketCategory("tc009", "Software Issue");
			TicketBean t=new TicketBean(ticketCategory,"Extra Details","low","new");
			boolean flag;
			flag=daoRef1.raiseNewTicket(t);
			assertTrue(flag);
			
			assertEquals(flag,true);
			
			assertFalse(!flag);
		
		}

		@After
		public void Finish()
		{
			daoRef1=null;
		}
	}
}
