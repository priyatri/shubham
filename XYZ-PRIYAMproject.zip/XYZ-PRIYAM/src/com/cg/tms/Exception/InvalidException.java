package com.cg.tms.Exception;

public class InvalidException extends Exception
{
}