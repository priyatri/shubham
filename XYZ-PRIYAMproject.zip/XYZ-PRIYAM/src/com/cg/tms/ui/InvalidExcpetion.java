package com.cg.tms.ui;

public class InvalidExcpetion extends Exception {

}
