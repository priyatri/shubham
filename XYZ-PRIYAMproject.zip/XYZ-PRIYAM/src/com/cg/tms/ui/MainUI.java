package com.cg.tms.ui;

import java.text.SimpleDateFormat;

import java.util.Date;

import java.util.List;
import java.util.Locale;
import java.util.Scanner;

import com.cg.tms.Exception.InvalidException;
import com.cg.tms.dto.*;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI
{

	public static void main(String[] args)throws InvalidException
	{
           // creating the reference of TicketService
		TicketService serRef = new TicketServiceImpl();
		List<TicketCategory> list;
		Scanner sc = new Scanner(System.in);
		int x = 1;
		int mainChoice;
		System.out.println("Welcome");
		System.out.println("1. Raise");
		System.out.println("2. Exit");
		mainChoice = Integer.parseInt(sc.nextLine());
		switch (mainChoice) {
		case 1: {

			list = serRef.listTicketCategory();
			System.out.println("Select Category:");
			for (TicketCategory t : list) {

				System.out.println(x + ": " + t.getCategoryName());
				x++;
			}
			System.out.println("Choose option:");
			int choice = Integer.parseInt(sc.nextLine());
			String tc = "";
			String tid = "";
			switch (choice) {
			case 1: {
				tid = list.get(0).getTicketCategoryId();
				tc = list.get(0).getCategoryName();
				break;
			}
			case 2: {
				tid = list.get(1).getTicketCategoryId();
				tc = list.get(1).getCategoryName();
				break;
			}
			case 3: {
				tid = list.get(2).getTicketCategoryId();
				tc = list.get(2).getCategoryName();
				break;
			}
			default: {
				System.out.println("wrong");
				System.exit(0);
			}
			}

			System.out.println("take description");
			String desc = sc.nextLine();

			System.out.println("take priority as (1: low/2: medium/3: high)");
			int pr = Integer.parseInt(sc.nextLine());
			String priority = "";
			switch (pr) {
			case 1:
				priority = "low";
				break;
			case 2:
				priority = "medium";
				break;
			case 3:
				priority = "high";
				break;
			default: {

				System.err.println("invalid Error Exception");
				throw new InvalidException();
				
				
			}
			}
			String ticketStatus = "new";

			TicketCategory ticketCategory = new TicketCategory(tid, tc);
			TicketBean tb = new TicketBean(ticketCategory, desc, priority, ticketStatus);

			SimpleDateFormat month_date = new SimpleDateFormat("dd MMMM yyyy hh:mm a", Locale.ENGLISH);
			Date date = new Date();
			String currdate = month_date.format(date);

			boolean f = serRef.raiseNewTicket(tb);
			if (f == true)
				System.out.println("Ticket Number " + tb.getTicketNo() + " Logged Successfully at " + currdate);
			break;
		}

		case 2:
		{
			System.exit(0);
		}
  default: System.out.println("wrong choice");
	}
}
}
