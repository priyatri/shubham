package BankApplication;

import java.util.LinkedList;

public class ICICIBank {
	LinkedList<Account> accounts=new LinkedList<>();
	public String createAccount(int accountnumber, int amount) 
	{
		Account account=new Account(accountnumber,amount);
		accounts.add(account);
		return "Account " +accountnumber+" created Successfully.";
	}
	
	private Account searchAccount(int accountnumber)throws InvalidAccountNumberException
	{
		for(Account account: accounts)
		{
			if(accountnumber==account.getAccountnumber())
			{
				return account;
			}
		}
		throw new InvalidAccountNumberException();
	}
	
    public String withdrawAmount(int accountnumber, int amount)throws InsufficientBalanceExcpetion, InvalidAccountNumberException 
	{
		Account account= searchAccount(accountnumber);
		if((account.getAmount()-amount)>0)
		{
			account.setAmount(account.getAmount()-amount);
			return "Balance of Account number "+ accountnumber+ " after withdraw= "+account.getAmount();
		}
		throw new InsufficientBalanceExcpetion();
	}
	public String depositAmount(int accountnumber, int amount) throws InvalidAccountNumberException {
		Account account= searchAccount(accountnumber);
		account.setAmount(account.getAmount()+amount);
		return "Balance of Account number "+ accountnumber+ " after deposit= "+ account.getAmount();
	}
	public String fundTransfer(int saccountNumber, int raccountNumber, int amount) throws InvalidAccountNumberException, InsufficientBalanceExcpetion {
		Account sAccount = searchAccount(saccountNumber);
		Account rAccount = searchAccount(raccountNumber);
		
		if(sAccount.getAmount()>=amount)
		{
			withdrawAmount(saccountNumber, amount);
			depositAmount(raccountNumber, amount);
			return "Fund trasferred from "+ saccountNumber +" to "+raccountNumber+" successfully. Now "+saccountNumber+" Balance= "+sAccount.getAmount()+" and "+raccountNumber+"balance="+rAccount.getAmount();
		}
		throw new InsufficientBalanceExcpetion();
	}
	
}

