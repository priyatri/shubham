package BankApplication;

@SuppressWarnings("serial")
public class InvalidAccountNumberException extends Exception {
	
	
}
