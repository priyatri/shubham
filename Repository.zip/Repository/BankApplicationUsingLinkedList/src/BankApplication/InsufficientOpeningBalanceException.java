package BankApplication;

@SuppressWarnings("serial")
public class InsufficientOpeningBalanceException extends Exception {
	

}
