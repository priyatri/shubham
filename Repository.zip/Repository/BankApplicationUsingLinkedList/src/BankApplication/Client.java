package BankApplication;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ICICIBank bank= new ICICIBank();
		System.out.println(bank.createAccount(101,0));
		System.out.println(bank.createAccount(102,0));
		System.out.println(bank.createAccount(103,0)+"\n");
		

			
		try {
			System.out.println(bank.depositAmount(101, 4000));
			System.out.println(bank.depositAmount(102, 4000));
			System.out.println(bank.depositAmount(103, 4000)+"\n");
		}
		catch(InvalidAccountNumberException ia) {
			System.out.println("Invalid Account Number.");
		}
		
		
		
		try {
			System.out.println(bank.withdrawAmount(101,2000));
			System.out.println(bank.withdrawAmount(102,1000));
			System.out.println(bank.withdrawAmount(103,500)+"\n");
		}
		catch(InvalidAccountNumberException ia) {
			System.out.println("Invalid Account Number.");
		}
		catch(InsufficientBalanceExcpetion ib) {
			System.out.println("Insufficient Balance");
		}

		
		try {
			System.out.println(bank.fundTransfer(101,102,500));
			System.out.println(bank.fundTransfer(101,103,500));
		}
		catch(InvalidAccountNumberException ia) {
			System.out.println("Invalid Account Number.");
		}
		catch(InsufficientBalanceExcpetion ia) {
			System.out.println("Insufficient Balance.");
		}
		
	}

}
