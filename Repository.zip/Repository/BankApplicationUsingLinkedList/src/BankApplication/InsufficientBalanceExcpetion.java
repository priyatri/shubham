package BankApplication;

@SuppressWarnings("serial")
public class InsufficientBalanceExcpetion extends Exception {



}