package com.capgemini.exception;

@SuppressWarnings("serial")
public class RatingNotMatchedException extends Exception {
	@Override
	public String getMessage()
	{
		return ("No Trainer is found with this rating.");
	}

}
