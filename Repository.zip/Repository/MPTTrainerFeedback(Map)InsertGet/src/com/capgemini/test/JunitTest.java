package com.capgemini.test;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatchedException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class JunitTest {
	public static FeedbackService fservice;

	@Before
	public void setUp() throws Exception {
	 fservice=new FeedbackServiceImpl();
	}
	
	@Test(expected=com.capgemini.exception.RatingNotMatchedException.class)
	public void WhenRatingNotMatchedItShouldThrowAnException() throws RatingNotMatchedException
	{
		fservice.getTrainerList(2);
	}
	
	@Test()
	public void TrainerListAlreadyExists() throws RatingNotMatchedException
	{
		Trainer trainer=new Trainer("Smitha","Java",LocalDate.parse("2013-03-20"),LocalDate.parse("2010-04-20"),5);
		assertEquals(trainer, fservice.getTrainerList(5).get(411));
	}
	
	@Test
	public void FeedbackAddedSuccessfully()
	{
		fservice.addFeedback(new Trainer("ravi", "java", LocalDate.parse("2010-11-12") , LocalDate.parse("2012-12-30"), 4));
		fservice.addFeedback(new Trainer("knt", "visual", LocalDate.parse("2010-11-12") , LocalDate.parse("2012-12-30"), 6));
	}
	
	

}
