package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map.Entry;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatchedException;
import com.capgemini.util.DBUtil;

public class FeedbackDAOImpl implements FeedbackDAO {

	// method definition to add the trainer feedback.
	@Override
	public Trainer addFeedback(Trainer trainer) {
		HashMap<Integer, Trainer> TrainerList = DBUtil.getFeedbackList();
		TrainerList.put(DBUtil.generateID(), trainer);
		return trainer;

	}

	// method declaration to get the feedback list.
	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws RatingNotMatchedException {
		HashMap<Integer, Trainer> TrainerList = DBUtil.getFeedbackList();

		// HashMap to store the searchedList in TrainerList and then in DBUtil Class.
		HashMap<Integer, Trainer> searchedList = new HashMap<>();

		for (Entry<Integer, Trainer> entry : TrainerList.entrySet()) {

			// to search whether the given rating is matched with the rating in the Trainer List.
			if (rating == entry.getValue().getRating())

			{
				searchedList.put(entry.getKey(), entry.getValue());
			}
		}
		return searchedList;
	}

}
