package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.FeedbackDAOImpl;
import com.capgemini.exception.RatingNotMatchedException;

public class FeedbackServiceImpl implements FeedbackService {

	FeedbackDAO dao=new FeedbackDAOImpl();
	@Override
	public Trainer addFeedback(Trainer trainer) {
		return dao.addFeedback(trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws RatingNotMatchedException {
		if(dao.getTrainerList(rating).size()==0)
		{
			throw new RatingNotMatchedException();
		}
		else
		{
			return dao.getTrainerList(rating);
		}
	}

}
