package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatchedException;

public interface FeedbackService {
	public Trainer addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList(int rating) throws RatingNotMatchedException;

}
