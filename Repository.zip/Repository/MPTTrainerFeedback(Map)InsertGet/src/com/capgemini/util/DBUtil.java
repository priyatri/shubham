package com.capgemini.util;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.beans.Trainer;

public class DBUtil {
	private static HashMap<Integer,Trainer> feedbackList=new HashMap<>();
	

	static{
		feedbackList.put(411,new Trainer("Smitha","Java",LocalDate.parse("2013-03-20"),LocalDate.parse("2010-04-20"),5));
		feedbackList.put(221,new Trainer("Smitha","Java",LocalDate.parse("2001-01-01"),LocalDate.parse("2010-01-20"),4));
	}
	
	public static HashMap<Integer, Trainer> getFeedbackList() {
		return feedbackList;
	}

	public static int generateID()
	{
		return (int) (Math.random()*1000);
	}
}
