package com.capgemini.view;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.RatingNotMatchedException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;


public class MainApp {
	public static FeedbackService fservice = new FeedbackServiceImpl();
	public static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws RatingNotMatchedException {
		
		while (true) {
			System.out.println("\n**********Trainer Feedback*********");
			System.out.println("1. Add the Feedback. \n" + "2. Display the details of trainer. \n" + "3. Exit.\n");
			
			System.out.println("Enter the choice: ");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				addFeedback();
				break;
			case 2:
				displaydetails();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice.");
			}
		}
	}

	private static void addFeedback() {
		System.out.println("Enter the name: ");
		
		String name =scanner.next();
		while(!(Pattern.matches("[A-Z,a-z, ]+", name)))
		{
			System.out.println("Enter a Valid name.");
			name=scanner.next();
		}
		scanner.nextLine();
		System.out.println("Enter the Course name: ");
		String courseName = scanner.next();
		System.out.println("Enter the Start date, in YYYY-MM-DD format: ");
		String sDate = scanner.next();
		while(!(dateValidate(sDate)))
		{
			System.out.println("Date is Invalid.");
			sDate = scanner.next();
		}
		System.out.println("Enter the end date, in YYYY-MM-DD format: ");
		String eDate = scanner.next();
		while(!(dateValidate(eDate)))
		{
			System.out.println("Date is Invalid.");
			eDate = scanner.next();
		}
		System.out.println("Enter the Rating: ");
		int rating =scanner.nextInt();
		while(rating<0||rating>10)
		{
			System.out.println("Enter the rating between 0-10.");
			rating=scanner.nextInt();
		}

		// Trainer trainer = new Trainer(name, courseName, StartDate, EndDate, rating);
		Trainer trainer = new Trainer();
		trainer.setName(name);
		trainer.setCourseName(courseName);
		trainer.setStartDate(LocalDate.parse(sDate));
		trainer.setEndDate(LocalDate.parse(eDate));
		trainer.setRating(rating);

		fservice.addFeedback(trainer);
		System.out.println("One Feedback added successfully.");

	}

	private static void displaydetails() {
		System.out.println("Enter that rating, you want to search the trainer accordingly: ");
		int rating1 = scanner.nextInt();
//		while(!(rating1<0||rating1>10))
//		{
//			System.out.println("Enter the rating between 0-10.");
//			rating1=scanner.nextInt();
//		}
		scanner.nextLine();
		try {
			System.out.println(fservice.getTrainerList(rating1));
		} catch (RatingNotMatchedException e) {
			System.out.println("");
			System.err.println(e.getMessage());
		}

	}
	public static boolean dateValidate(String date)
	{
		try
		{
			LocalDate.parse(date);
			return true;
		}
		catch(Exception e)
		{
			System.err.println("Please! Enter a Valid Date.");
			return false;
		}
	}

}
