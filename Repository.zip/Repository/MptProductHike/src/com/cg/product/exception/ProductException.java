package com.cg.product.exception;

@SuppressWarnings("serial")
public class ProductException extends Exception {
	public ProductException(String string) {
		System.out.println(string);

}

}
