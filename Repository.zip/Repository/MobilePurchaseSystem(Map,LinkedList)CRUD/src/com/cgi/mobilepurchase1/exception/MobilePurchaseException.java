package com.cgi.mobilepurchase1.exception;


public class MobilePurchaseException extends Exception{
	private static final long serialVersionUID = 1L;

	public MobilePurchaseException(String message) {
    	   super(message);
       }

	
}
