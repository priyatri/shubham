package com.capgemini.exception;

@SuppressWarnings("serial")
public class MobileNumberNotExistException extends Exception {

}
