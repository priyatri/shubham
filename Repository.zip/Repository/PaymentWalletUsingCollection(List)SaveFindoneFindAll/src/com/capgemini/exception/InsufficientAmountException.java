package com.capgemini.exception;

@SuppressWarnings("serial")
public class InsufficientAmountException extends Exception {

}
