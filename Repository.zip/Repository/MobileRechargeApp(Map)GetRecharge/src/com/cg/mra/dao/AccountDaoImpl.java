package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	
	Map<String, Account> accountEntry;
	
	public AccountDaoImpl() {
		
	accountEntry=new HashMap<String, Account>();
	
	accountEntry.put("7388067166", new Account("Prepaid", "Saurabh",200));
	accountEntry.put("9696341082", new Account("Prepaid", "Ravi",300));
	accountEntry.put("9389971139", new Account("Prepaid", "Prashant",600));
	accountEntry.put("8960919536", new Account("Prepaid", "Simran", 500));
	
	}
	
	@Override
	public Account getAccountDetails(String mobileNo) {
		
		if(accountEntry.containsKey(mobileNo))
			return accountEntry.get(mobileNo);
	
	return null;
	}
	
	

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		double balance=0;
		if(accountEntry.containsKey(mobileNo)){
			Account acc= accountEntry.get(mobileNo);
			   balance= rechargeAmount+acc.getAccountBalance();
			acc.setAccountBalance(balance);
		}
		
		// TODO Auto-generated method stub
		
		return balance;
	}

}
