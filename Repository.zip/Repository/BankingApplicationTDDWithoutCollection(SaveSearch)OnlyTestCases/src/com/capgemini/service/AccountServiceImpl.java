package com.capgemini.service;

import com.capgemini.beans.Account;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InsufficientOpeningBalanceException;
import com.capgemini.exception.InvalidAccountNumberException;
import com.capgemini.repo.AccountRepo;

public class AccountServiceImpl implements AccountService{
	AccountRepo accountRepo;

	public AccountServiceImpl(AccountRepo accountrepo) {
		super();
		this.accountRepo = accountrepo;
	}
	
	@Override
	public Account createAccount(int accountnumber, int amount) throws InsufficientOpeningBalanceException {
		// TODO Auto-generated method stub
		if(amount<500)
		{
			throw new InsufficientOpeningBalanceException();
		}
		Account account=new Account();
		account.setAccountnumber(accountnumber);
		account.setAmount(amount);
		if(accountRepo.save(account))
		{
			return account;
		}
		return null;
	}

	@Override
	public int depositAmount(int accountnumber, int amount) throws InvalidAccountNumberException {
		// TODO Auto-generated method stub
		Account account =accountRepo.searchAccount(accountnumber);
		if(account==null)
		{
			System.out.println("From if Statement.");
			throw new InvalidAccountNumberException();
		}
		account.setAmount(account.getAmount()+amount);
		accountRepo.save(account);
		System.out.println("after save.");
		return account.getAmount();
	}

	@Override
	public int withdrawAmount(int accountnumber, int amount) throws InvalidAccountNumberException, InsufficientBalanceException {
		// TODO Auto-generated method stub
		Account account =accountRepo.searchAccount(accountnumber);
		if(account==null)
		{
			throw new InvalidAccountNumberException();
		}
		if(account.getAmount()<amount)
		{
			throw new InsufficientBalanceException();
		}
		account.setAmount(account.getAmount()-amount);
		accountRepo.save(account);
		return account.getAmount();
		
	}
	

		}

