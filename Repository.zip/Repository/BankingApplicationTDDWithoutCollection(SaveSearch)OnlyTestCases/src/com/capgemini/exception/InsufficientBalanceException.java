package com.capgemini.exception;

@SuppressWarnings("serial")
public class InsufficientBalanceException extends Exception {

}
