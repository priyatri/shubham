package com.capgemini.exception;

@SuppressWarnings("serial")
public class InsufficientOpeningBalanceException extends Exception {

}
