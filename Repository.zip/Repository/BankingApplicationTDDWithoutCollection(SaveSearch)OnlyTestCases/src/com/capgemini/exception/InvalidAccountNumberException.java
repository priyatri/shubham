package com.capgemini.exception;

@SuppressWarnings("serial")
public class InvalidAccountNumberException extends Exception {

}
