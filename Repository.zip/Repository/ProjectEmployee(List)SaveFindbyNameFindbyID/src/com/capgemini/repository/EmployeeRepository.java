package com.capgemini.repository;

import java.util.List;

import com.capgemini.beans.Employee;
import com.capgemini.exception.EmployeeDoesNotExist;

public interface EmployeeRepository {
	Employee save(Employee e);
	List<Employee> findByName(String employeeName) throws EmployeeDoesNotExist;
	boolean findId(int id);

}
