package com.capgemini.repository;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.capgemini.beans.Employee;
import com.capgemini.exception.EmployeeDoesNotExist;

public class EmployeeRepositoryImpl implements EmployeeRepository {
	HashMap<Integer,Employee> hm= new HashMap<>();
 
	@Override
	public Employee save(Employee employee) {
		hm.put(employee.getEmployeeID(), employee);
		return employee;
	}

	@Override
	public List<Employee> findByName(String employeeName) throws EmployeeDoesNotExist {
		// TODO Auto-generated method stub
		boolean b=true;
		List<Employee> employees=new LinkedList<>();
		for(Map.Entry<Integer,Employee> entry : hm.entrySet()) {
			if(entry.getValue().getEmployeeName().equals(employeeName)) {
				b=false;
				employees.add(entry.getValue());
			}
			}
		if(b)
			throw new EmployeeDoesNotExist();
		
		return employees;
		
}
	@Override
	public boolean findId(int id) {
		// TODO Auto-generated method stub
		for (Map.Entry<Integer,Employee>  iter : hm.entrySet()) {
			  if (iter.getKey()==id ) {
			    // do something
				  return true;
			  }
			}
		return false;
	}
}