package com.capgemini.view;

import java.util.List;

import com.capgemini.beans.Address;
import com.capgemini.beans.City;
import com.capgemini.beans.Country;
import com.capgemini.beans.Employee;
import com.capgemini.exception.DuplicateIdException;
import com.capgemini.exception.EmployeeDoesNotExist;
import com.capgemini.exception.InvalidAddressException;
import com.capgemini.exception.InvalidIdException;
import com.capgemini.exception.InvalidNameException;
import com.capgemini.exception.SearchByNullException;
import com.capgemini.repository.EmployeeRepository;
import com.capgemini.repository.EmployeeRepositoryImpl;
import com.capgemini.service.EmployeeService;
import com.capgemini.service.EmployeeServiceImpl;

public class Main {

	public static EmployeeRepository employeeRepo = new EmployeeRepositoryImpl();
	public static EmployeeService employeeService = new EmployeeServiceImpl(employeeRepo);
	
	public static void main(String[] args) throws SearchByNullException, InvalidIdException, InvalidNameException, DuplicateIdException, InvalidAddressException, EmployeeDoesNotExist {
		City Varanasi = new City("Varanasi");
		City Melbourne = new City("Melbourne");
		
		Country india = new Country("India",Varanasi);
		Country Australia = new Country("France",Melbourne);
		
		System.out.println(employeeService.createEmployee(1, "Saurabh", new Address("F1",india)));
		System.out.println(employeeService.createEmployee(2, "Ravi", new Address("F2", Australia)));
		System.out.println(employeeService.createEmployee(3, "Prashant", new Address("F1",india)));
		System.out.println(employeeService.createEmployee(4, "Simran", new Address("F2",Australia)));
		System.out.println(employeeService.createEmployee(5, "Saurabh", new Address("F2",Australia)));
		
		List<Employee> list = employeeService.searchByName("Saurabh");
	
		for(Employee employee:list) 
		{
		System.out.println(employee);
		}
}}

