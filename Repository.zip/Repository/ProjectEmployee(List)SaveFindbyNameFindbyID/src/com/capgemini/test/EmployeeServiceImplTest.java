package com.capgemini.test;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Address;
import com.capgemini.beans.City;
import com.capgemini.beans.Country;
import com.capgemini.exception.DuplicateIdException;
import com.capgemini.exception.EmployeeDoesNotExist;
import com.capgemini.exception.InvalidAddressException;
import com.capgemini.exception.InvalidIdException;
import com.capgemini.exception.InvalidNameException;
import com.capgemini.exception.SearchByNullException;
import com.capgemini.repository.EmployeeRepository;
import com.capgemini.repository.EmployeeRepositoryImpl;
import com.capgemini.service.EmployeeService;
import com.capgemini.service.EmployeeServiceImpl;

public class EmployeeServiceImplTest {
	   
	   //@Mock
	   EmployeeRepository employeeRepo=new EmployeeRepositoryImpl();
	   EmployeeService employeeService=new EmployeeServiceImpl(employeeRepo);


	@Test(expected=com.capgemini.exception.InvalidIdException.class)
	public void test() throws InvalidIdException, DuplicateIdException, InvalidNameException, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country("India",city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(-1, "Saurabh", address));
	}
	
	
	@Test
	public void test6() throws InvalidIdException, DuplicateIdException, InvalidNameException, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country("India",city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(1, "Saurabh", address));
	}
	
	@Test(expected=com.capgemini.exception.DuplicateIdException.class)
	public void test1() throws InvalidIdException, DuplicateIdException, InvalidNameException, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country("India",city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(1, "Saurabh", address));
		
		City city1=new City("Melbourne");
		Country country1 = new Country("Australia",city1);
		Address address1 = new Address("MCG",country1);
		employeeRepo.save(employeeService.createEmployee(1, "Saurabh", address1));
	}
	
	
	@Test(expected=com.capgemini.exception.InvalidNameException.class)
	public void test2() throws InvalidIdException, DuplicateIdException, InvalidNameException, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country("India",city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(1, null, address));
	}
	
	
	
	@Test(expected=com.capgemini.exception.EmployeeDoesNotExist.class)
	public void test3() throws InvalidIdException, DuplicateIdException, InvalidNameException, EmployeeDoesNotExist, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country("India",city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(1, "Saurabh", address));
		employeeRepo.findByName("Krishan");

	}
	
	
	
	
	@Test(expected=com.capgemini.exception.SearchByNullException.class)
	public void test4() throws SearchByNullException, InvalidIdException, DuplicateIdException, InvalidNameException, EmployeeDoesNotExist, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country("India",city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(1, "Saurabh", address));
		employeeService.searchByName(null);

	}
	
	
	@Test
	public void test5() throws SearchByNullException, InvalidIdException, DuplicateIdException, InvalidNameException, EmployeeDoesNotExist, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country("India",city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(1, "Saurabh", address));

	}
	
	
	
	@Test(expected=com.capgemini.exception.InvalidAddressException.class)
	public void test7() throws InvalidIdException, DuplicateIdException, InvalidNameException, InvalidAddressException {
		City city=new City("Varanasi");
		Country country = new Country(null,city);
		Address address = new Address("Durgakund",country);
		employeeRepo.save(employeeService.createEmployee(1, "Saurabh", address));
	}
}
