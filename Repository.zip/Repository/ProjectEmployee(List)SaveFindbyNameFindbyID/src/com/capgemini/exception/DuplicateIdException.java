package com.capgemini.exception;

@SuppressWarnings("serial")
public class DuplicateIdException extends Exception {

}
