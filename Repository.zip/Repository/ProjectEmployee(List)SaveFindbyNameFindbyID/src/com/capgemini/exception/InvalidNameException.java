package com.capgemini.exception;

@SuppressWarnings("serial")
public class InvalidNameException extends Exception {

}
