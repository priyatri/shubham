package com.capgemini.exception;

@SuppressWarnings("serial")
public class InvalidIdException extends Exception {

}
