package com.capgemini.exception;

@SuppressWarnings("serial")
public class SearchByNullException extends Exception {

}
