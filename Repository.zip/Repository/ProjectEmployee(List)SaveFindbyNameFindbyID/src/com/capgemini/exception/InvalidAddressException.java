package com.capgemini.exception;

@SuppressWarnings("serial")
public class InvalidAddressException extends Exception {

}
