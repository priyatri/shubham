package com.capgemini.exception;

@SuppressWarnings("serial")
public class EmployeeDoesNotExist extends Exception {

}
