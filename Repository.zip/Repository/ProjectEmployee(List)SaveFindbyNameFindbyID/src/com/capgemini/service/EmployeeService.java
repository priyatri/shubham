package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Address;
import com.capgemini.beans.Employee;
import com.capgemini.exception.DuplicateIdException;
import com.capgemini.exception.EmployeeDoesNotExist;
import com.capgemini.exception.InvalidAddressException;
import com.capgemini.exception.InvalidIdException;
import com.capgemini.exception.InvalidNameException;
import com.capgemini.exception.SearchByNullException;

public interface EmployeeService {
	Employee createEmployee(int employeeID, String employeeName, Address address) throws InvalidIdException, InvalidNameException, DuplicateIdException, InvalidAddressException;
	List<Employee> searchByName(String employeeName) throws SearchByNullException, EmployeeDoesNotExist;

}
