package com.capgemini.service;

import java.util.List;

import com.capgemini.beans.Address;
import com.capgemini.beans.Employee;
import com.capgemini.exception.DuplicateIdException;
import com.capgemini.exception.EmployeeDoesNotExist;
import com.capgemini.exception.InvalidAddressException;
import com.capgemini.exception.InvalidIdException;
import com.capgemini.exception.InvalidNameException;
import com.capgemini.exception.SearchByNullException;
import com.capgemini.repository.EmployeeRepository;

public class EmployeeServiceImpl implements EmployeeService {
	int i=1;
	EmployeeRepository employeeRepo;

	public EmployeeServiceImpl(EmployeeRepository employeeRepo) {
		super();
		this.employeeRepo = employeeRepo;
	}

	@Override
	public Employee createEmployee(int employeeID, String employeeName, Address address) throws InvalidIdException, InvalidNameException, DuplicateIdException, InvalidAddressException {
		// TODO Auto-generated method stub
		
		if(employeeID<0)
		{
			throw new InvalidIdException();
		}
		
		if(employeeName==null)
		{
			throw new InvalidNameException();
		}
		
		if(employeeRepo.findId(employeeID))
		{
			throw new DuplicateIdException();
		}
		
		if((address==null)||(address.getAddressLine()==null)||(address.getCountry().getCountryName()==null)||(address.getCountry().getCity().getCityname()==null))
		{
			throw new InvalidAddressException();
		}
		
		
		Employee employee = new Employee(employeeName, i, address);
		//employee.setEmployeeName(employeeName);
		//employee.setAddress(address);
		//employeeRepo.save(employee);
		i=i+1;
		return employeeRepo.save(employee);
		
	}

	@Override
	public List<Employee> searchByName(String employeeName) throws SearchByNullException, EmployeeDoesNotExist {
		// TODO Auto-generated method stub
		if(employeeName==null)
			throw new SearchByNullException();
		
	
		return employeeRepo.findByName(employeeName);
	}
}
