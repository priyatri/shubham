package com.capgemini.beans;

public class Country {
	@Override
	public String toString() {
		return " countryName=" + countryName + ", city=" + city + "";
	}
	private String countryName;
	City city;
	public Country(String countryName, City city) {
		super();
		this.countryName = countryName;
		this.city = city;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public City getCity() {
		return city;
	}
	public void setCity(City city) {
		this.city = city;
	}

}
