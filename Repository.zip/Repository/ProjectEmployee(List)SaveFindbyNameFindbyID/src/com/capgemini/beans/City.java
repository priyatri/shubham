package com.capgemini.beans;

public class City {
	@Override
	public String toString() {
		return "Cityname=" + cityname + "]";
	}

	private String cityname;

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public City(String cityname) {
		super();
		this.cityname = cityname;
	}
	

}
