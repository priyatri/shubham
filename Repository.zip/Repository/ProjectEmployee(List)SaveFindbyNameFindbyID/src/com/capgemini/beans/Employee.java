package com.capgemini.beans;

public class Employee {
	@Override
	public String toString() {
		return "Employee [Name=" + employeeName + ", ID=" + employeeID + ", Address=" + address + "\n";
	}
	private String employeeName;
	private int employeeID;
	Address address;
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Employee(String employeeName, int employeeID, Address address) {
		super();
		this.employeeName = employeeName;
		this.employeeID = employeeID;
		this.address = address;
	}

}
