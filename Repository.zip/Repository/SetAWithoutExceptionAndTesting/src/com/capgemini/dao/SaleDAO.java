package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map.Entry;

import com.capgemini.beans.Sale;
import com.capgemini.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {
	
	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		HashMap<Integer,Sale> SaleList=(HashMap<Integer, Sale>) CollectionUtil.getCollection();
		int key=CollectionUtil.generateSaleId();
		sale.setSaleID(key);
		SaleList.put(key, sale);
		return SaleList;
	}

	@Override
	public Sale getSaleDetails(int prodCode) {
		HashMap<Integer,Sale> SaleList=(HashMap<Integer, Sale>) CollectionUtil.getCollection();
		for(Entry<Integer,Sale> entry:SaleList.entrySet())
		{
			if(prodCode==entry.getKey())
			{
				return entry.getValue();
			}
		}
		return null;
	}


}
