package com.capgemini.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.beans.Sale;

public class CollectionUtil{
private static Map<Integer, Sale>  sales=new HashMap<Integer, Sale>();
static {
	sales.put(1002, new Sale(1001, "iPhone","Electronics", 35000));
	sales.put(1001, new Sale(1002, "LEDTV","Electronics", 45000));	
	sales.put(1003, new Sale(1003, "Teddy","Toys", 800));
	sales.put(1004, new Sale(1004, "Telescope","Toys", 5000));
	
      }
public static Map<Integer, Sale> getCollection() {
	return sales;
}
public static int generateSaleId()
{
	int saleId=(int) (Math.random()*1000);
	return saleId;
}
}