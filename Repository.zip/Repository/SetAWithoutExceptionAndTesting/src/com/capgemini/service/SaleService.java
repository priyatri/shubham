package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Sale;
import com.capgemini.dao.ISaleDAO;
import com.capgemini.dao.SaleDAO;

public class SaleService implements ISaleService {
	
	@Override
	public Sale getSaleDetails(int prodCode) {
		ISaleDAO saleDAO = new SaleDAO();
		return saleDAO.getSaleDetails(prodCode);
	}

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		ISaleDAO saleDAO = new SaleDAO();
		return saleDAO.insertSaleDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productID) {
		if (productID == 1001 || productID == 1002 || productID == 1003 || productID == 1004)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateQuantity(int qty) {
		if (qty > 0 && qty < 5)
			return true;
		else
			return false;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		if (prodCat.equals("Electronics") || prodCat.equals("Toys"))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateProductName(String prodName) {
//		Pattern.matches("[A-Z,a-z, ]", prodName)||
		if (prodName.equals("TV") || prodName.equals("Smart Phone")
				|| prodName.equals("Video Game") || prodName.equals("Soft Toy") || prodName.equals("Telescope")
				|| prodName.equals("Barbee Doll"))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateProductPrice(float price) {
		if(price>200)
	return true;
	else
		return false;
	}

}
