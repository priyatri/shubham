package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Sale;

public interface ISaleService {
	
	public HashMap<Integer,Sale> insertSalesDetails(Sale sale);
	public boolean validateProductCode(int productID);
	public boolean validateQuantity(int qty);
	public boolean validateProductCat(String prodCat);
	public boolean validateProductName(String prodName);
	public boolean validateProductPrice(float price);
	
	public Sale getSaleDetails(int prodCode);
}
