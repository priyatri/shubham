package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.beans.Sale;
import com.capgemini.service.ISaleService;
import com.capgemini.service.SaleService;

public class MainApp {
	static ISaleService saleService = new SaleService();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		while (true) {
			System.out.println("******ABC Billing Software Application*********");
			System.out.println("Choose: \n");
			System.out.println("1. To store the sale details. \n"
					+ "2. To get the product information and get the final bill. \n" + "3. Exit. \n");
			System.out.println("Enter your choice: ");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				addSaleDetails();
				break;
			case 2:
				getProductInformation();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid choice. \n");
			}
		}
	}

	private static void addSaleDetails() {
		System.out.println("Enter the product code: ");
		int prodCode = scanner.nextInt();
		while (!(saleService.validateProductCode(prodCode))) {
			System.out.println("Enter a valid Product Code:");
			prodCode = scanner.nextInt();
		}
		System.out.println("Enter the Product Category: ");
		String prodCat = scanner.next();
		while (!(saleService.validateProductCat(prodCat))) {
			System.out.println("Enter a valid Product category: ");
			prodCat = scanner.next();
		}
		scanner.nextLine();
		System.out.println("Enter the Product name: ");
		String prodName = scanner.nextLine();
		while (!(saleService.validateProductName(prodName))) {
			System.out.println("Enter a valid product name: ");
			prodName = scanner.nextLine();
		}
		System.out.println("Enter the product price: ");
		float price = scanner.nextFloat();
		while (!(saleService.validateProductPrice(price))) {
			System.out.println("Enter a price greater than 200: ");
			price = scanner.nextFloat();
		}
		Sale sale = new Sale();
		sale.setProdCode(prodCode);
		sale.setCategory(prodCat);
		sale.setProductName(prodName);
		sale.setLineTotal(price);
//		sale.setSaleID(CollectionUtil.generateSaleId());
		saleService.insertSalesDetails(sale);
		System.out.println("Product Details added successfully.");
		System.out.println("Your Sale Id is "+sale.getSaleID());

	}

	private static void getProductInformation() {
		System.out.println("Enter the Sale Id");
		int saleId=scanner.nextInt();
		System.out.println("Enter the Quantity: ");
		int qty = scanner.nextInt();
		Sale sale = saleService.getSaleDetails(saleId);
		System.out.println("Product Category: " + sale.getCategory() + "\n." + "Product Name: " + sale.getProductName()
				+ "\n." + "Product Price: " + sale.getLineTotal() + "\n." + "Quantity: " + qty + "\n."
				+ "Line Total(Rs.): " + (sale.getLineTotal() * qty) + "\n.");
	}

}
