package com.capgemini.salesmanagement.exception;

@SuppressWarnings("serial")
public class ProductNameNotMatchedException extends Exception {

}
