package com.capgemini.beans;

public class Address {

}
