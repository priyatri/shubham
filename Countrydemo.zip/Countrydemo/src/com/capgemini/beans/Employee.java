package com.capgemini.beans;

public class Employee {

}
