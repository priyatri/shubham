package com.capgemini.repo;

public class EmployeeRepoImpl {

}
