package com.capgemini.exceptions;

public class NameShouldNotBeNull extends Exception {

}
