package com.capgemini.main;

import com.capgemini.Exception.ProductIdInvalidException;

public class Entry
{
public static void main(String[]args) throws ProductIdInvalidException
{
	ProductDAO dao=new ProductDAO();
ProductService rev=new ProductService(dao);
