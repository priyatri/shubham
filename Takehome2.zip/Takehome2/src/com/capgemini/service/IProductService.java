package com.capgemini.service;

import com.capgemini.Exception.ProductIdInvalidException;
import com.capgemini.beans.Product;

public interface IProductService
{
Product getProductDetails(int productcode)throws ProductIdInvalidException;
}
