package com.capgemini.service;

import com.capgemini.Exception.ProductIdInvalidException;
import com.capgemini.beans.Product;
import com.capgemini.dao.ProductDAO;

public class ProductService implements IProductService
{
ProductDAO ref=new ProductDAO();

@Override
public Product getProductDetails(int productcode) throws ProductIdInvalidException {
	return ref.getProductDetails(productcode);
}
}

	