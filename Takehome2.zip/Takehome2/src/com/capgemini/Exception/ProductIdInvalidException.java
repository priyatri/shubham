package com.capgemini.Exception;

public class ProductIdInvalidException extends Exception
{

}
