package com.capgemini.dao;

import com.capgemini.Exception.ProductIdInvalidException;
import com.capgemini.beans.Product;

public interface IProductDAO 
{
Product getProductDetails(int productcode)throws ProductIdInvalidException;
}
