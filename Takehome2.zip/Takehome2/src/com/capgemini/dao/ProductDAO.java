package com.capgemini.dao;


import com.capgemini.Exception.ProductIdInvalidException;
import com.capgemini.beans.Product;
import com.capgemini.util.CollectionUtil;

public class ProductDAO implements IProductDAO
{
CollectionUtil util;
Product product;


	@Override
	public Product getProductDetails(int productcode) throws ProductIdInvalidException {
	product= CollectionUtil.getProducts().get(productcode);
	if(product==null)
	{
		throw new ProductIdInvalidException();
	}
		return product;

	}
}

