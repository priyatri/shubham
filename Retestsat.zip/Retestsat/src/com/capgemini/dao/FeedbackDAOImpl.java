package com.capgemini.dao;

import java.util.HashMap;

import com.capgemini.Utility.Util;
import com.capgemini.beans.Trainer;

public class FeedbackDAOImpl implements FeedbackDAO
{
	HashMap<Integer,Trainer> hm;

	@Override
	public void addFeedback(Trainer trainer) 
	{

		hm=Util.feedbackList;
		int v=(int)(Math.random()*1000);
		hm.put(v, trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		hm=Util.feedbackList;
		return hm;
	}
}

	

	