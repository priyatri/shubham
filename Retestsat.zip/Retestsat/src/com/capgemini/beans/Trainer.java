package com.capgemini.beans;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Trainer {
	String name;
	String coursename;
	LocalDate startdate;
	LocalDate enddate;
	int rating;
	DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-YYYY");
	public Trainer(String name, String coursename, String string1, String string2, int rating)
	{
		this.name = name;
		this.coursename = coursename;
		this.startdate = LocalDate.parse(string1,formatter);
		this.enddate = LocalDate.parse(string2, formatter);
		this.rating = rating;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public LocalDate getStartdate() {
		return startdate;
	}
	public void setStartdate(LocalDate startdate) {
		this.startdate = startdate;
	}
	public LocalDate getEnddate() {
		return enddate;
	}
	public void setEnddate(LocalDate enddate) {
		this.enddate = enddate;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public DateTimeFormatter getFormatter() {
		return formatter;
	}
	public void setFormatter(DateTimeFormatter formatter) {
		this.formatter = formatter;
	}
}
