package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.FeedbackDAOImpl;

public class FeedbackSeviceImpl implements FeedbackService
{
	FeedbackDAOImpl ref=new FeedbackDAOImpl();
    HashMap<Integer,Trainer> hn;

	@Override
	public void addFeedback(Trainer trainer)
	{
		ref.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList()
	{
    return ref.getTrainerList();
	
	}

}
