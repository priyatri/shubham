package com.capgemini.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.Exception.FeedbackRatingCannotBeNullException;
import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.FeedbackDAOImpl;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackSeviceImpl;

public class testcase
{
	@Before
	public void setup() throws Exception
	{
	FeedbackService ref = new FeedbackSeviceImpl();
	}
		
@Test(expected=FeedbackRatingCannotBeNullException.class)
public void test1() throws FeedbackRatingCannotBeNullException
{
	Trainer tr=new Trainer("priya","java","26-01-2016","28-06-2019",3);
	tr.setCoursename("Java");
	tr.setName("priya");
	tr.setRating(3);
	tr.setStartdate(LocalDate.parse("26-01-2016"));
	tr.setEnddate(LocalDate.parse("28-06-2019"));
	ref.addFeedback(tr);
}
@Test

public void test2() throws FeedbackRatingCannotBeNullException
{
	Trainer tr=new Trainer("priyam","html","28-04-2013","12-04-2018",2);
	tr.setCoursename("html");
	tr.setName("priyam");
	tr.setRating(2);
	tr.setStartdate(LocalDate.parse("28-04-2013"));
	tr.setEnddate(LocalDate.parse("12-04-2018"));
	ref.addFeedback(tr);
}	
}
	
	
