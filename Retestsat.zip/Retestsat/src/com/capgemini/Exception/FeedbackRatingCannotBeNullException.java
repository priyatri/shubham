package com.capgemini.Exception;

public class FeedbackRatingCannotBeNullException extends Exception 
{

}
