import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import com.capgemini.beans.Trainer;
import com.capgemini.service.FeedbackServiceImpl;

import cm.cg.Exception.FeedbackRatingException;

public class main
{
public static void main(String[] args) throws FeedbackRatingException
{
	FeedbackServiceImpl ser= new FeedbackServiceImpl();
	Scanner sc=new Scanner(System.in);

	System.out.println("1.Store the details of Trainer");
	System.out.println("2.Display");
	System.out.println("3.Exit");
	System.out.println("Enter your choice");
	int choice=sc.nextInt();
	switch(choice)
	{
	case 1:
	{
		System.out.println("enter trainer name");	
	String s=sc.next();
	System.out.println("enter course name");	
	String d=sc.next();
	System.out.println("enter start date(dd-MM-yyyy)");	
	String sd=sc.next();
	System.out.println("enter end date(dd-MM-yyyy)");	
	String ed=sc.next();
	System.out.println("enter feedback rating");	
	int a=sc.nextInt();
	

	Trainer tre= new Trainer(s,d,sd,ed,a);
	
       ser.addFeedback(tre);
      Map<Integer,Trainer> tre1=ser.getTrainerList();
	for(Map.Entry<Integer, Trainer> i: tre1.entrySet())
	{
		System.out.println(i.getValue().getName());
		System.out.println(i.getValue().getCoursename());
		System.out.println(i.getValue().getStartDate());
		System.out.println(i.getValue().getEnddate());
		System.out.println(i.getValue().getRating());
	
	}
	break;
}

	case 2:
	{
		int flag=0;
		System.out.println("enter the rating"); 
		int rating=sc.nextInt();
		 Map<Integer,Trainer> tre2=ser.getTrainerList();
		 
	for(Entry<Integer, Trainer> i: tre2.entrySet())
	{
		if(rating==i.getValue().getRating())
		{
	System.out.println(i.getValue().getName());
	System.out.println(i.getValue().getCoursename());
	System.out.println(i.getValue().getStartDate());
	System.out.println(i.getValue().getEnddate());
	System.out.println(i.getValue().getRating());
	flag=1;
	
	}
	}
	 if(flag==0)
	 {
		 throw new FeedbackRatingException();
	 }
	
	 break;
	}
	
	
	case 3:
	 {
		 System.exit(0);
	 }
	}
}
}

	







	
