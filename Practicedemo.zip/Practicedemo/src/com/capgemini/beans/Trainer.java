package com.capgemini.beans;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Trainer 
{
String name;
String coursename;
 LocalDate startDate;
LocalDate  endDate;
int rating;
DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");
public Trainer(String name, String coursename, String string, String string1, int rating)
{
	this.name = name;
	this.coursename = coursename;
	this.startDate = LocalDate.parse(string, formatter);
	this.endDate = LocalDate.parse(string1, formatter);
	this.rating = rating;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCoursename() {
	return coursename;
}
public void setCoursename(String coursename) {
	this.coursename = coursename;
}
public LocalDate getStartDate() {
	return startDate;
}
public void setStartDate(LocalDate startDate) {
	this.startDate = startDate;
}
public LocalDate getEnddate() {
	return endDate;
}
public void setEnddate(LocalDate enddate) {
	this.endDate = enddate;
}
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
@Override
public String toString() {
	return "Trainer [name=" + name + ", coursename=" + coursename + ", startDate=" + startDate + ", endDate=" + endDate
			+ ", rating=" + rating + ", formatter=" + formatter + "]";
}



}
