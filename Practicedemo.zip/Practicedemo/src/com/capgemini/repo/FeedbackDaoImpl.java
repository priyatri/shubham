package com.capgemini.repo;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.util.DBUtil;

public class FeedbackDaoImpl implements FeedbackDao  {
HashMap<Integer,Trainer> red;
	@Override
	public void addFeedback(Trainer trainer)
	{
		red= DBUtil.feedbackList;
	 int v=(int)( Math.random()*1000);
		red.put(v, trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() 
	{
		red=DBUtil.feedbackList;
		return red;
	
	}

}
