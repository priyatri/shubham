package com.capgemini.service;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.beans.Trainer;
import com.capgemini.repo.FeedbackDaoImpl;

public class FeedbackServiceImpl implements FeedbackService
{
FeedbackDaoImpl ref= new FeedbackDaoImpl();
	@Override
	public void addFeedback(Trainer trainer) {
		
		ref.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList()
	{
	return ref.getTrainerList();
			

}
}
