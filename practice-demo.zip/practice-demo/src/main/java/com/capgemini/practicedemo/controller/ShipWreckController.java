package com.capgemini.practicedemo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.practicedemo.dto.Shipwreck;
import com.capgemini.practicedemo.dto.ShipwreckStub;

@RestController
@RequestMapping("api/v1")
public class ShipWreckController {

	@RequestMapping(method = RequestMethod.GET, value = "shipwrecks")
	public List<Shipwreck> list() {

		return ShipwreckStub.list();
	}

	@RequestMapping(method = RequestMethod.POST, value = "shipwrecks")
	public Shipwreck save(@RequestBody Shipwreck shipwreck) {
		return shipwreck;

	}

	@RequestMapping(method = RequestMethod.GET, value = "shipwrecks/{id}")
	public Shipwreck get(@PathVariable(name = "id") long id) {
		return ShipwreckStub.get(id);

	}

	@RequestMapping(method = RequestMethod.PUT, value = "shipwrecks/{id}")
	public Shipwreck update(@RequestBody Shipwreck shipwreck, @PathVariable(name = "id") long id) {

		return ShipwreckStub.update(id, shipwreck);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "shipwrecks/{id}")
	public Shipwreck delete(@PathVariable(name = "id") long id) {

		return ShipwreckStub.delete(id);
	}
}
