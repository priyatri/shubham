package com.capgemini.practicedemo;

public class HelloController {

}
