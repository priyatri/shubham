package com.capgemini.practicedemo;

public class Shipwreck {

}
